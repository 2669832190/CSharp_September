﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 考试内容
{
    //租借系统
    internal class RentalSystem
    {
        private List<Car> cars = new List<Car>();

        //构造函数
        public RentalSystem()
        {
            Car car1 = new Car() { brand = Brand.宝马, model = "X", licensePlate = get8NumberRandom(), rent = 100 };
            Car car2 = new Car() { brand = Brand.大众, model = "迈腾", licensePlate = get8NumberRandom(), rent = 50 };
            Car car3 = new Car() { brand = Brand.五菱, model = "宏光", licensePlate = get8NumberRandom(), rent = 9.9 };
            //添加到车库
            cars.Add(car1);
            cars.Add(car2);
            cars.Add(car3);
        }

        //添加一辆车
        public void AddCar(Brand inputBrand, string inputModel, double inputRent)
        {
            Car car1 = new Car() { brand = inputBrand, model = inputModel, licensePlate = get8NumberRandom(), rent = inputRent };
            cars.Add(car1);
        }

        //删除一辆车
        public void DelCar(string inputLicensePlate)
        {
            for(int i = 0; i < cars.Count; i++)
            {
                //如果某辆车的车牌号 == 输入的车牌号
                if (cars[i].licensePlate == inputLicensePlate)
                {
                    //删除这辆车
                    cars.RemoveAt(i);
                }
            }
        }

        //打印汽车信息
        public void PrintCars()
        {
            foreach(Car car in cars)
            {
                Console.WriteLine($"车的品牌:{car.brand},型号:{car.model},车牌号:{car.licensePlate}," +
                    $"租金:{car.rent},是否租出:{car.isLease},租借天数:{car.leaseDate}");
            }
        }

        //租车
        //如果没有找到这辆车 或者 已经被借出了 会返回0
        //否则返回租金
        public double CarRental(string inputLicensePlate,int rentDay)
        {
            //找到这辆车
            for(int i = 0;i < cars.Count;i++)
            {
                if (cars[i].licensePlate == inputLicensePlate)
                {
                    //判断这辆车是否已经被租出
                    if (cars[i].isLease == true)
                    {
                        //等于true 说明已经被借出了
                        return 0;
                    }

                    //代码只要能运行到这里 车一定是没有被租出去的
                    cars[i].isLease = true;
                    cars[i].leaseDate = rentDay;

                    //计算租金 并返回出去
                    double money = cars[i].rent * rentDay;
                    return money;
                }
            }
            //没有找到这辆车
            return 0;
        }

        //还车
        //输入车牌号和实际使用的天数
        //没有找到这辆车 或者 没有被借出 返回0
        //否则返回应当补足多少元 如果是负数 表示应当退还多少元
        public double ReturnCar(string inputLicensePlate,int rentDay)
        {
            //先找到这辆车
            for(int i = 0;i < cars.Count; i++)
            {
                if (cars[i].licensePlate == inputLicensePlate)
                {
                    if (cars[i].isLease == false)
                    {
                        //没有被借出
                        return 0;
                    }
                    //如果代码运行到这里 说明车是已经被借出了
                    //借出状态改为没有借出
                    cars[i].isLease= false;

                    if(rentDay > cars[i].leaseDate)
                    {
                        //实际使用天数 > 租借天数
                        return (rentDay - cars[i].leaseDate) * cars[i].rent * 2;
                    }
                    else
                    {
                        //退还的钱
                        //假设 实际借5天 应当借10天 租金20
                        //(5 - 10) * 20 == -100
                        return (rentDay - cars[i].leaseDate) * cars[i].rent;
                    }
                }
            }
            //没找到这辆车
            return 0;
        }

        #region 获取随机数
        //获取8位随机数的方法
        Random ran = new Random();
        //只要调用这个方法 就能拿到8位的车牌号
        private string get8NumberRandom()
        {
            string str = "豫";
            //[65,91)
            char c = (char)ran.Next(65, 91);
            //豫 + 我们随机出来的A-Z的字符
            str += c;
            //后面还有6位
            int Number = ran.Next(100000, 1000000);
            str += Number;
            //返回出去
            return str;
        }
        #endregion
    }
}
