﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 考试内容
{
    public enum Brand
    {
        宝马,
        大众,
        五菱,
        长城,
        丰田
    }

    internal class Car
    {
        //品牌
        public Brand brand { get; set; }
        //型号
        public string model { get; set; }
        //车牌号
        public string licensePlate { get; set; }
        //租金
        public double rent {  get; set; }
        //是否已租出
        public bool isLease { get; set; }
        //租借天数
        public int leaseDate { get; set; }
    }
}
