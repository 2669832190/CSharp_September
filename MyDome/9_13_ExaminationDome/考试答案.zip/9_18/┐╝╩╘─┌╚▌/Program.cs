﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 考试内容
{
    internal class Program
    {
        static RentalSystem RentalSystem = new RentalSystem();
        static void Main(string[] args)
        {
            Console.WriteLine("欢迎来到租车系统");
            while (true)
            {
                //先打印车辆信息
                RentalSystem.PrintCars();

                Console.WriteLine("请输入要进行的操作:1.添加车辆 2.删除车辆 3.借车 4.还车 5.退出");
                int number = Convert.ToInt32(Console.ReadLine());
                switch (number)
                {
                    case 1:
                        AddCar();
                        break;
                    case 2:
                        DelCar();
                        break;
                    case 3:
                        CarRental();
                        break;
                    case 4:
                        ReturnCar();
                        break;
                    case 5:
                        return;
                    default:
                        Console.WriteLine("输入的内容不合法，请重新输入!");
                        break;
                }
            }
        }

        //添加汽车
        static void AddCar()
        {
            Console.WriteLine("请输入车的品牌:0.宝马 1.大众 2.五菱");
            int brandInt = Convert.ToInt32(Console.ReadLine());
            Brand brand = (Brand)brandInt;

            Console.WriteLine("请输入车的型号:");
            string model = Console.ReadLine();

            Console.WriteLine("请输入车的租金:");
            double rent = Convert.ToDouble(Console.ReadLine());

            RentalSystem.AddCar(brand, model, rent);
        }

        //删除汽车
        static void DelCar()
        {
            Console.WriteLine("请输入要删除的车牌号:");
            string str = Console.ReadLine();
            RentalSystem.DelCar(str);
        }

        //借车
        static void CarRental()
        {
            Console.WriteLine("请输入要借的车牌号:");
            string inputLicensePlate = Console.ReadLine();
            Console.WriteLine("请输入要借的天数:");
            int day = Convert.ToInt32(Console.ReadLine());

            double money = RentalSystem.CarRental(inputLicensePlate, day);
            if (money == 0)
            {
                Console.WriteLine("没找到这辆车或已被借出!");
            }
            else
            {
                Console.WriteLine($"成功借到这辆车,租金是:{money}");
            }
        }

        //还车
        static void ReturnCar()
        {
            Console.WriteLine("请输入车牌号:");
            string inputLicensePlate = Console.ReadLine();

            Console.WriteLine("请输入实际使用的天数:");
            int day = Convert.ToInt32(Console.ReadLine());

            double money = RentalSystem.ReturnCar(inputLicensePlate, day);
            if (money == 0)
            {
                Console.WriteLine("没有找到这辆车 或者 没有被借出!");
            }else if(money > 0)
            {
                Console.WriteLine($"应当补足{money}元");
            }
            else
            {
                Console.WriteLine($"应当退还{-money}元");
            }
        }
    }
}
