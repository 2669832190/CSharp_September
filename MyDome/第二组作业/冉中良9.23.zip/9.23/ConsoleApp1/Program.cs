﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace ConsoleApp1
{
    internal class Program
        
    {
        static void Main(string[] args)
        { }//. 使用正则表达式验证IP地址 (如192.168.1.1)
         //  ^(?: (?: 25[0 - 5] | 2[0 - 4][0 - 9] | [01]?[0 - 9][0 - 9] ?)\.){ 3} (?: 25[0 - 5] | 2[0 - 4][0 - 9] | [01]?[0 - 9][0 - 9] ?)$

public class IPAddressValidator
        {
            public static bool IsValidIPAddress(string ipAddress)
            {
                string pattern = @"^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$";
                return Regex.IsMatch(ipAddress, pattern);
            }

            public static void Main()
            {
                string ip = "192.168.1.1";
                bool isValid = IsValidIPAddress(ip);
                Console.WriteLine($"Is '{ip}' a valid IP address? {isValid}");
            }
        }
        //第2提
        public class ProvincesForm : Form
        {
            private ComboBox comboBoxProvince;
            private ComboBox comboBoxCity;
            private ComboBox comboBoxCounty;

            public ProvincesForm()
            {
                comboBoxProvince = new ComboBox();
                comboBoxCity = new ComboBox();
                comboBoxCounty = new ComboBox();

                // 省份下拉框的选择改变事件
                comboBoxProvince.SelectedIndexChanged += ComboBoxProvince_SelectedIndexChanged;

                Controls.Add(comboBoxProvince);
                Controls.Add(comboBoxCity);
                Controls.Add(comboBoxCounty);
            }

            private void ComboBoxProvince_SelectedIndexChanged(object sender, EventArgs e)
            {
                string selectedProvince = comboBoxProvince.SelectedItem.ToString();
                // 根据选择的省份加载城市
                comboBoxCity.Items.Clear();
                // 这里是获取省份对应的城市列表的逻辑
                comboBoxCity.Items.Add("城市1");
                comboBoxCity.Items.Add("城市2");
                // ...

                // 根据选择的城市加载区县
                comboBoxCounty.Items.Clear();
                // 这里是获取城市对应的区县列表的逻辑
                comboBoxCounty.Items.Add("区县1");
                comboBoxCounty.Items.Add("区县2");
                // ...
            }

            [STAThread]
            static void Main()
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new ProvincesForm());
            }
        }
    }
    }

