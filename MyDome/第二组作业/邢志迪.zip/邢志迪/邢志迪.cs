﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _9._23作业__2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Dictionary<string, Dictionary<string, List<string>>> list = new Dictionary<string, Dictionary<string, List<string>>>()
        {
            { "河南省",new Dictionary<string, List<string>>
                {
                { "郑州市",new List<string>
                   {
                       "新郑市",
                       "荥阳市"
                   }
                },
                {
                    "新乡市",new List<string>
                    {
                        "原阳县",
                        "获嘉县"
                    }
                }
                } 
            },
            { "山东省",new Dictionary<string, List<string>>
            {
                {"青岛市",new List<string>
                {
                    "市南区",
                    "市北区"
                }
                },
                {"日照市",new List<string>
                {
                    "五莲县",
                    "莒县"
                }
                }
            } 
            }
           
        };
        
        
        private void Form1_Load(object sender, EventArgs e)
        {
            foreach (var  item in list)
            {
                province.Items.Add(item.Key);
            }

        }

        private void province_SelectedIndexChanged(object sender, EventArgs e)
        {
            city.Items.Clear();

            string str=province.SelectedItem .ToString();

            if (list.ContainsKey(str))
            {
                Dictionary<string,List<string>> dict = list[str];
                foreach (var itme in dict)
                {
                    city.Items.Add (itme.Key);
                }
            }
        }
       
        private void city_SelectedIndexChanged(object sender, EventArgs e)
        {
            county.Items.Clear();

            string str = province.SelectedItem .ToString();
            if ( list.ContainsKey(str))
            {
                Dictionary<string, List<string>> dict = list[str];
                string s = city.SelectedItem.ToString();
                if (dict.ContainsKey(s))
                {
                    county.Items.AddRange(dict[s].ToArray());
                }
            }
            

        }
    }
}
