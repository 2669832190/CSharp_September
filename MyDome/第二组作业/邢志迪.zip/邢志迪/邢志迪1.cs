﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace _9._23作业_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //1. 使用正则表达式验证IP地址 (如192.168.1.1)

            Console.WriteLine( "请输入一个IP地址");
            string str= Console.ReadLine();

            Regex reg = new Regex(@"^\d{3}.\d{3}.\d.\d{1}$");
            if ( reg.IsMatch(str))
            {
                Console.WriteLine( "IP地址正确");
                Match m = reg.Match(str);
                Console.WriteLine(m.Value);
            }
            else
            {
                Console.WriteLine( "IP地址格式不正确");
            }
            //Match m = reg.Match(str);
            //Console.WriteLine( m.Value );
            
        }
    }
}
